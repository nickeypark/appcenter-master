﻿using System.Net.Http;
using Acquaint.Abstractions;

namespace Acquaint.XForms.UWP
{
    public class HttpClientHandlerFactory : IHttpClientHandlerFactory
    {
        public HttpClientHandler GetHttpClientHandler()
        {
            return null;
        }
    }
}
